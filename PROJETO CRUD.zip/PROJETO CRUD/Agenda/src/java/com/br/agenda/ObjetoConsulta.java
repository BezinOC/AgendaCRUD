/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.agenda;


/**
 *
 * @author Bernardo
 */
public class ObjetoConsulta{
    
    private String nomePaciente;
    private String sobrenomePaciente;
    private String obs;
    private int id_consulta;
    private String horario;
    //public DadosConsulta(String nomePaciente, String sobrenomePaciente, String obs) {
    //    this.nomePaciente = nomePaciente;
    //    this.sobrenomePaciente = sobrenomePaciente;
    //    this.obs = obs;
    //}
    
    public ObjetoConsulta(String nomePaciente, String sobrenomePaciente, String obs, int id_consulta, String horario) {
        this.nomePaciente = nomePaciente;
        this.sobrenomePaciente = sobrenomePaciente;      
        this.obs = obs;
        this.id_consulta = id_consulta;
        this.horario = horario;
    }
    
    
    
    public String getNomePaciente() {
        return this.nomePaciente;
    }
    
    public void setNomePaciente(String novoNome) {
        this.nomePaciente = novoNome;
    }
    
    public String getSobrenomePaciente() {
        return this.sobrenomePaciente;
    }
    
    public void setSobrenomePaciente(String novoSobrenome) {
        this.sobrenomePaciente = novoSobrenome;
    }
    
    public String getObs() {
        return this.obs;
    }
    
    public void setObs(String novaObs) {
        this.obs = novaObs;
    }
    
    public int getId_consulta() {
        return this.id_consulta;
    }
    
    public void setId_consulta(int novoId) {
        this.id_consulta = novoId;
    }
    
    public String getHorario() {
        return this.horario;
    }
    
    public void setHorario(String novoHorario) {
        this.horario = novoHorario;
    }
    
}
