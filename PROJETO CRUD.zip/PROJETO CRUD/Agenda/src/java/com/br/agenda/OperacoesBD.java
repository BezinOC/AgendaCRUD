/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.agenda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bernardo
 */

public class OperacoesBD extends Conexao{
    
    //url de conexão
    String url = "jdbc:sqlite:C:/Users/Bernardo/Documents/NetBeansProjects/banco_sqlite.db";
    
    
    public void criarTabela() {
       
        //comando sql de criar tabela com nome, sobrenome e observações
        String sql = "CREATE TABLE IF NOT EXISTS tabela_agendamentos (\n"
                + "id_consulta integer PRIMARY KEY, \n"
                + "nome text NOT NULL, \n"
                + "sobrenome text NOT NULL, \n"
                + "horario text NOT NULL, \n"
                + "obs text NOT NULL \n"
                + ");";
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            Statement stmt = conn.createStatement();
            //executa a instrução de sql
            stmt.execute(sql);
            
            System.out.println("Tabela foi criada ou já existe!");
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }   
    }
    
    
    public void inserir(String nome, String sobrenome, String horario,String obs) {
        
        //comando sql de inserir
        String sql = "INSERT INTO tabela_agendamentos (nome, sobrenome, horario, obs) VALUES (?, ?, ?,?)";
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            PreparedStatement pstmt = conn.prepareStatement(sql);
            //atribui cada entrada a posição correspondente na tabela
            pstmt.setString(1, nome);
            pstmt.setString(2, sobrenome);
            pstmt.setString(3, horario);
            pstmt.setString(4, obs);
            //executa a instrução de sql
            pstmt.executeUpdate();
            
            System.out.println("Consulta inserida com sucesso!");
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }   
    }
    
    
    public void selecionar() {
        
        String sql = "SELECT id_consulta, nome, sobrenome, horario, obs FROM tabela_agendamentos";
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            Statement stmt = conn.createStatement();
            //retorna o resultado da query
            ResultSet res = stmt.executeQuery(sql);
            
            while(res.next()) {
                System.out.println(res.getInt("id_consulta") + " "
                                + res.getString("nome") + " "
                                + res.getString("sobrenome") + " "
                                + res.getString("horario") + " "
                                + res.getString("obs"));
            }
            
          
            System.out.println("Busca geral concluida com sucesso!");
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }
    }
    
    
    public List<ObjetoConsulta> selecionarTodos() {
        
        String sql = "SELECT id_consulta, nome, sobrenome, horario, obs FROM tabela_agendamentos";
        List<ObjetoConsulta> listaConsultas = new ArrayList<>(); 
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            Statement stmt = conn.createStatement();
            //retorna o resultado da query
            ResultSet res = stmt.executeQuery(sql);
            
            while(res.next()) {
                listaConsultas.add(new ObjetoConsulta(
                                res.getString("nome"),
                                res.getString("sobrenome"),
                                res.getString("obs"),
                                res.getInt("id_consulta"),
                                res.getString("horario")));
            }
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }
        
        return listaConsultas;
    }
 
    
    public void atualizar(int id_consulta, String nome, String sobrenome, String horario, String obs) {
    
        String sql = "UPDATE tabela_agendamentos SET nome = ?, sobrenome = ?, horario = ?, obs = ? WHERE id_consulta = ?";
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            PreparedStatement pstmt = conn.prepareStatement(sql);
            //atribui cada entrada a posição correspondente na tabela
            pstmt.setString(1, nome);
            pstmt.setString(2, sobrenome);
            pstmt.setString(3, horario);
            pstmt.setString(4, obs);
            pstmt.setInt(5, id_consulta);
            //executa a instrução de sql
            pstmt.executeUpdate();
            
            System.out.println("Atualização realizada com sucesso!");
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }    
    }
    
    
    public void deletarPorID (int id_consulta) {
    
        String sql = "DELETE FROM tabela_agendamentos WHERE id_consulta = ?";
        
        try {
            //conecta com o banco de dados
            Connection conn = DriverManager.getConnection(url);
            //cria o objeto statement de sql
            PreparedStatement pstmt = conn.prepareStatement(sql);
            //atribui cada entrada a posição correspondente na tabela
            pstmt.setInt(1, id_consulta);
            //executa a instrução de sql
            pstmt.executeUpdate();
            
            System.out.println("Deleção realizada com sucesso!");
        }
        
        catch(SQLException e) {
            System.err.println(e.getMessage());
        }  
    }
    
}
