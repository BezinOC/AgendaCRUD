/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.agenda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Bernardo
 */

public class Conexao{
    
    private Connection conexao;
    
    public boolean conectar() throws ClassNotFoundException, SQLException{
        
        try {
            //comando para abrir a biblioteca do sqlite
            Class.forName("org.sqlite.JDBC");
            //url de conexao
            String url = "jdbc:sqlite:C:/Users/Bernardo/Documents/NetBeansProjects/banco_sqlite.db";
            //conectar com o banco
            this.conexao = DriverManager.getConnection(url);
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        System.out.println("Conectado com o banco");
        return true;
    }

    public boolean desconectar(){
        try {
            if(this.conexao.isClosed() == false){
                this.conexao.close();
            }
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        System.out.println("Desconectado com o banco");
        return true;
    }
    
}
