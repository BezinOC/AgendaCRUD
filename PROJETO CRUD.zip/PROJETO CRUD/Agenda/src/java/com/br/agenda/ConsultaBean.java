/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.br.agenda;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Bernardo
 */
@ManagedBean
@SessionScoped
public class ConsultaBean extends OperacoesBD{
    
    private String nomePaciente;
    private String sobrenomePaciente;
    private String obs;
    private String mensagem;
    private int id_consulta;
    private String horario;
    
    private List<ObjetoConsulta> listaConsultas = new ArrayList<>(); 
    //public DadosConsulta(String nomePaciente, String sobrenomePaciente, String obs) {
    //    this.nomePaciente = nomePaciente;
    //    this.sobrenomePaciente = sobrenomePaciente;
    //    this.obs = obs;
    //}
    
    
    public void create() {
       OperacoesBD Agenda = new OperacoesBD();
    }
    
    public void insert() throws ClassNotFoundException, SQLException {
      Conexao conn = new Conexao();
      conn.conectar();
      
      OperacoesBD Agenda = new OperacoesBD();
      Agenda.criarTabela();
      
      Agenda.inserir(nomePaciente, sobrenomePaciente, horario, obs);
      mensagem = "Consulta inserida";
      
      listaConsultas = Agenda.selecionarTodos();
      conn.desconectar();
    }
    
    public void read() throws ClassNotFoundException, SQLException {
      Conexao conn = new Conexao();
      conn.conectar();
      
      OperacoesBD Agenda = new OperacoesBD();
      Agenda.criarTabela();
      listaConsultas = Agenda.selecionarTodos();
      
      conn.desconectar();
    }
    
    public void delete(int id_consulta) throws ClassNotFoundException, SQLException {
      Conexao conn = new Conexao();
      conn.conectar();
      
      OperacoesBD Agenda = new OperacoesBD();
      Agenda.criarTabela();
      
      Agenda.deletarPorID(id_consulta);
      
      listaConsultas = Agenda.selecionarTodos();
      conn.desconectar();
    }
    
    public void edit(int id_consulta, String nome, String sobrenome, String horario, String obs) throws ClassNotFoundException, SQLException {
      Conexao conn = new Conexao();
      conn.conectar();
      
      OperacoesBD Agenda = new OperacoesBD();
      Agenda.criarTabela();
      
      Agenda.atualizar(id_consulta, nome, sobrenome, horario, obs);
      
      listaConsultas = Agenda.selecionarTodos();
      conn.desconectar();
    }
    
    public void limpar() {
        nomePaciente = null;
        sobrenomePaciente = null;
        horario = null;
        obs = null;
    }
    
    public String getNomePaciente() {
        return nomePaciente;
    }
    
    public void setNomePaciente(String novoNome) {
        this.nomePaciente = novoNome;
    }
    
    public String getSobrenomePaciente() {
        return sobrenomePaciente;
    }
    
    public void setSobrenomePaciente(String novoSobrenome) {
        this.sobrenomePaciente = novoSobrenome;
    }
    
    public String getObs() {
        return obs;
    }
    
    public void setObs(String novaObs) {
        this.obs = novaObs;
    }
    
    public String getMensagem() {
        return mensagem;
    }
    
    public void setMensagem(String novaMensagem) {
        this.mensagem = novaMensagem;
    }
    
    public int getId_consulta() {
        return id_consulta;
    }
    
    public void setId_consulta(int novoId) {
        this.id_consulta = novoId;
    }
    
    public List<ObjetoConsulta> getListaConsultas() {
        return listaConsultas;
    }
    
    public void setListaConsultas(List<ObjetoConsulta> novaListaConsultas) {
        this.listaConsultas = novaListaConsultas;
    }
    
    public String getHorario() {
        return horario;
    }
    
    public void setHorario(String novoHorario) {
        this.horario = novoHorario;
    }
    
}
